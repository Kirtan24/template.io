# Tests for Template Management System (backend)

This folder contains unit, integration and specification-based tests for the backend (`template-back`).

Structure:

- `unit/controllers` - unit tests for controllers (mocked models and services)
- `unit/services` - unit tests for services (mail, cloudinary)
- `integration` - route-level tests using `supertest`
- `spec` - specification (property-based) tests using `fast-check`

Run tests:

```powershell
cd "D:\Projects\Template Management System\template-back"
npm install
npm test
```

Mapping (examples):

- `test/unit/controllers/auth.controller.test.js` -> `src/controllers/auth.controller.js` (login, register, forgot/reset password)
- `test/integration/auth.route.test.js` -> mounted auth routes with `supertest`

Mocking strategy:

- Mongoose models: `mockingoose`
- External services (email/cloudinary): jest mocks or sinon stubs
- For integration tests, we mount routers to an express app and mock models rather than starting the main server
