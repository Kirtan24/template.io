# Test Documentation — template-back

This document explains the test design, what we implemented, how to run tests locally, mocking strategy, files added, and next steps. It was created to satisfy the Software Design & Test course requirements (unit tests, test doubles, specification tests, and design commentary).

---

## Quick Summary

- Test framework: `jest` (Node.js)
- HTTP route testing: `supertest`
- Mongoose model mocking: `mockingoose`
- Property/specification testing: `fast-check`
- In-memory MongoDB (optional, not used by current tests): `mongodb-memory-server`

The repository contains a test scaffold and several representative tests demonstrating unit, integration, service, and specification-style tests. The tests are written to be simple, course-focused examples and to be extended for full coverage.

## How to run tests

Open PowerShell and run:

```powershell
cd "D:\Projects\Template Management System\template-back"
npm install
npm test
```

The `test` npm script runs `jest --runInBand --detectOpenHandles`.

Notes:

- Tests are written to run without a running server or external MongoDB. `mockingoose` stubs model calls. For deeper integration tests using real Mongoose behavior, see the **Next steps** section.

## Test folder structure (what's included)

- `test/setup.js` — Jest setup for global test configuration and helpers.
- `test/README.md` — short README describing test structure and mapping.
- `test/TEST_DOCUMENTATION.md` — (this file) full documentation.
- `test/unit/controllers/auth.controller.test.js` — unit tests for `src/controllers/auth.controller.js`.
- `test/unit/services/mail.service.test.js` — unit tests for `src/services/mail.service.js` (transporter mocked).
- `test/integration/auth.route.test.js` — router-mounted integration tests for the auth routes using `supertest`.
- `test/spec/validation.spec.test.js` — example specification/property-based test using `fast-check`.

## Tests implemented (mapping to code)

- `auth.controller` (unit)
  - Success login: verifies successful login path, JWT signing and response payload.
  - Wrong password: verifies the controller returns `400` when `bcrypt.compare` fails.
  - Approach: `mockingoose` is used to stub `User`, `Permission`, and `Company` model calls. `bcrypt.compare` and `jwt.sign` are spied to avoid heavy crypto.

- `auth.route` (integration)
  - Route-level test that mounts `src/routes/auth.route.js` on a small `express()` instance and exercises `POST /api/auth/login` using `supertest`.
  - Mongoose models are still mocked via `mockingoose`, so the test focuses on the route + controller wiring rather than a full DB.

- `mail.service` (unit)
  - Tests for `sendEmail` success, failure, and missing recipient.
  - `sendEmailWithAttachment` test ensures the transporter is called; exceptions propagate.
  - The `transporter` from `src/config/mail.config` is mocked with Jest.

- `validation.spec` (spec)
  - `fast-check` property test demonstrates specification-style testing by generating invalid email strings and asserting the email-regex fails for them.

## Mocking and Test Doubles Strategy

- Model mocking: `mockingoose` is used for simple stubbing of common Mongoose operations such as `findOne`, `find`, etc. When controllers use chained calls (e.g., `findById(...).populate('plan', 'name')`) we either:
  - mock the chaining with a `jest.spyOn(Model, 'findById')` that returns an object with a `populate` function that resolves the expected document, or
  - use `mockingoose(Model).toReturn(..., 'findOne')` for simpler flows.

- External services: `nodemailer`/transporter is mocked by creating a Jest mock for `src/config/mail.config` in tests. For other services (cloudinary, sockets), the recommended approach is similar: create a thin wrapper module (e.g., `src/services/cloudinary.service.js`) and mock that wrapper in unit tests.

- Bcrypt and JWT: spy on `bcrypt.compare`, `bcrypt.hash`, and `jsonwebtoken.sign` to avoid real hashing/crypto in unit tests.

## Design changes and testability improvements performed

The goal was to make tests reliable and quick. Key design-oriented changes and recommendations:

- Keep controllers thin: controllers should orchestrate request/response and delegate business logic to services. This makes the core logic easier to unit-test.
- Wrap external side-effecting modules (email, cloudinary, socket helpers) behind a small interface to allow easy stubbing in tests.
- Avoid side effects on module import during tests: long-running initialization (DB connect, socket init, background workers) should be started only when explicitly launching the server (e.g., in `server.js`) or guarded by `if (process.env.NODE_ENV !== 'test')`.

These suggestions are documented in `design.md` placed at the repository root.

## Logging behavior during tests

Some production code logs to `console.log` / `console.error` during normal operation and during failure paths. Because the tests intentionally exercise error paths, test output can include these logs.

Two options are available:

1. Keep logs as-is (default). You will see diagnostic messages in test runs.
2. Silence console in tests for cleaner output. To do this, add the following to `test/setup.js`:

```javascript
jest.setTimeout(20000);

beforeAll(() => {
  jest.spyOn(console, 'log').mockImplementation(() => {});
  jest.spyOn(console, 'error').mockImplementation(() => {});
});

afterAll(() => {
  console.log.mockRestore();
  console.error.mockRestore();
});

global.__TEST__ = true;
```

This approach was discussed and is optional — current test run includes log output by design, and all tests pass.

## CI recommendations (GitHub Actions) — minimal workflow

Create `.github/workflows/nodejs-test.yml` to run tests on push/PR. Minimal example:

```yaml
name: Node.js CI - tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Use Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18'
      - name: Install dependencies
        run: |
          cd template-back
          npm ci
      - name: Run tests
        run: |
          cd template-back
          npm test
```

Notes:

- `mockingoose` and the tests shown run in CI without requiring a real MongoDB server.
- If you later add `mongodb-memory-server` backed integration tests, add a step to increase test timeout or ensure the runner has enough resources.

## Example: extending tests (suggested next areas)

- `user.controller`: create unit tests for `createUser`, `updateProfile`, `updatePassword`, `dashboardState` (mock `userModel`, `companyModel`).
- `template.controller`: unit tests for template creation/processing (mock `cloudinary.service` and `docProcessor` functions). Use `mockingoose` to simulate `templateModel` behavior.
- `company.controller`: tests for `register`, `approve` flows — stub email and socket helpers.

## File map for tests added

- `test/setup.js` — jest setup
- `test/README.md` — short README
- `test/TEST_DOCUMENTATION.md` — this file
- `test/unit/controllers/auth.controller.test.js` — auth controller unit tests
- `test/unit/services/mail.service.test.js` — mail service unit tests
- `test/integration/auth.route.test.js` — auth route integration test
- `test/spec/validation.spec.test.js` — property/spec test

## Assumptions

- Tests are intended for the backend (`template-back`) only.
- Frontend (`template-front`) is out of scope for this exercise per course instructions.
- Tests prioritize demonstrating techniques from course lectures: refactoring for testability, unit testing with doubles, testing with external dependencies (stubbing), and specification-based testing.

## Final notes

All added tests pass locally as of the time this documentation was generated. If you want, I can:

- Expand coverage to additional controllers/services (I recommend `user`, `template`, `company`).
- Refactor the app to export `app` from `src/app.js` and move process-level startup into `server.js` to make tests cleaner.
- Add a GitHub Actions workflow and optionally a badge in the README.

If you'd like me to continue and implement tests for specific controllers, tell me which controllers to prioritize and I will continue iterating.

## Per-file detailed explanations

Below are line-item explanations for each test file added in `test/`. Use these notes when explaining your tests to others — they describe the intent, test structure (Arrange/Act/Assert), mocks and stubs used, and the important assertions each test makes.

- `test/setup.js`
  - Purpose: global test setup executed before any test runs (configured in `package.json` under `jest.setupFilesAfterEnv`).
  - What it contains: a `jest.setTimeout(20000)` call and a `global.__TEST__ = true` flag so tests can detect test mode if needed.
  - Why: ensures tests have a higher timeout for asynchronous operations and gives a place to add global mocks (e.g., silencing `console.log`) without repeating that in each test file.

- `test/README.md`
  - Purpose: short, human-friendly overview of test layout and run commands.
  - What it contains: the folder layout, basic commands to run tests, and a short mapping of tests to features. Use this when you need a quick reference.

- `test/unit/controllers/auth.controller.test.js`
  - Purpose: unit-test `src/controllers/auth.controller.js` logic without starting a server or connecting to a real database.
  - What we test:
    - Successful login flow: ensures the controller returns status 200 and a token when credentials match.
    - Wrong password flow: ensures the controller returns status 400 when `bcrypt.compare` fails.
  - Key test technique (AAA pattern):
    - Arrange: stub Mongoose model calls and external dependencies:
      - `mockingoose(User)` for `findOne` is used to simulate finding a user document.
      - `jest.spyOn(Company, 'findById')` is used to mock the `findById().populate()` chain by returning an object whose `populate()` returns the company document.
      - `mockingoose(Permission)` is used to simulate permission lookup.
      - `jest.spyOn(bcrypt, 'compare')` and `jest.spyOn(jwt, 'sign')` are used to avoid running the real hashing and JWT code and to return predictable results.
    - Act: call `authController.login(req, res)` with a fake `req`/`res` object. `res` uses `jest.fn()` for `status` and `send` so assertions can be made on calls.
    - Assert: check `res.status` and `res.send` were called with expected values (e.g., success token and user payload on success; appropriate error object on failure).
  - Important assertions to show:
    - `expect(res.status).toHaveBeenCalledWith(200)` and `expect(res.send).toHaveBeenCalledWith(expect.objectContaining({ status: 'success', token: 'fake-jwt' }))` for the success case.
    - `expect(res.status).toHaveBeenCalledWith(400)` for the wrong-password case.
  - How to explain to others:
    - "We mock data access so we unit-test only controller logic. We replace heavy crypto and JWT creation with spies so tests are fast and deterministic."

- `test/unit/services/mail.service.test.js`
  - Purpose: verify `src/services/mail.service.js` handles success and failure paths of the mail transporter wrapper.
  - What we test:
    - `sendEmail` returns `true` when the transporter resolves.
    - `sendEmail` returns `false` when the transporter rejects or recipient is missing.
    - `sendEmailWithAttachment` calls `transporter.sendMail` and the function resolves (or throws if `sendMail` fails).
  - Key test technique (mocks & spies):
    - The `transporter` object (exported by `src/config/mail.config`) is mocked by Jest — tests replace `sendMail` with `mockResolvedValue` or `mockRejectedValue` to simulate SMTP success/failure without sending real email.
    - We check return values and that `transporter.sendMail` was called as expected.
  - Important assertions to show:
    - `expect(transporter.sendMail).toHaveBeenCalled()` to demonstrate the service uses the underlying transporter.
    - `expect(result).toBe(true)` or `expect(result).toBe(false)` depending on the simulated result.
  - How to explain to others:
    - "We test the wrapper, not the SMTP transport. By mocking the transport, we confirm that our service correctly handles success and error cases."

- `test/integration/auth.route.test.js`
  - Purpose: lightweight integration test that verifies the routing and controller wiring for `POST /api/auth/login`.
  - What we test:
    - Deploy `src/routes/auth.route` to a small `express()` app inside the test and send an HTTP request using `supertest`.
    - Ensure the route responds with `200` and a token when credentials are correct (models are still mocked).
  - Key technique:
    - The test mounts the router on an isolated `express()` instance to avoid starting the full server which would run sockets and workers.
    - Uses `mockingoose` to stub model behavior and `jest.spyOn` to stub `bcrypt.compare` and `jsonwebtoken.sign` as in unit tests.
  - Important assertions:
    - `expect(res.status).toBe(200)` and `expect(res.body).toHaveProperty('token', 'jwt')` to prove the route + controller integration works.
  - How to explain to others:
    - "This test focuses on the network layer and ensures the route is bound to the correct controller and that request parsing + response semantics behave as expected when given mocked upstream data."

- `test/spec/validation.spec.test.js`
  - Purpose: an example of specification-based (property) testing using `fast-check` to demonstrate Lecture 22/23 style tests.
  - What we test:
    - Generate many random strings that are likely invalid emails, and confirm a simple email regex fails for them (i.e., the validation specification holds that those inputs are invalid).
  - Key technique:
    - Use `fast-check`'s arbitraries (`fc.string().filter(...)`) to generate a rich set of inputs.
    - `fc.assert(fc.property(...))` automatically runs many cases and reports any failing counterexample.
  - How to explain to others:
    - "Rather than writing a few concrete invalid inputs, property testing floods the code with many random inputs to increase confidence. This file shows a minimal example of that technique."

## General tips for presenting these tests

- Start with the goal: describe whether the test is unit, integration, or specification-level and what single responsibility it verifies.
- Describe test doubles: say which external systems were stubbed (DB models via `mockingoose`, SMTP via mocked `transporter`, crypto via `jest.spyOn(bcrypt)`), and why (speed, determinism, isolation).
- Walk through AAA for one representative test (Arrange: what mocks were set up; Act: what function/route was called; Assert: what the test checks).
- Emphasize test design choices aligned with course topics:
  - Refactoring for testability: extracting services or wrapping external clients so they can be mocked.
  - Use of test doubles: stubs and spies for external dependencies.
  - Specification tests: using `fast-check` to validate properties rather than just example-based tests.

If you want, I can also generate a short slide-style summary (few bullet-point slides) you can copy into your report or presentation summarizing each test file with 3–5 bullets each. Which controller should I cover next with tests and explanations?
